import { StyleSheet, Text, View } from 'react-native';
import React from 'react';
import { Provider } from 'react-redux';
import store from './store';
import ProductList from './ProductList';
import Cart from './Cart';

const products = [
  { id: 1, name: 'Product 1', imageUrl: 'https://i.pinimg.com/236x/19/d8/51/19d851065d0fa43c356328bcec240bf9.jpg' },
  { id: 2, name: 'Product 2', imageUrl: 'https://i.pinimg.com/236x/72/2a/7e/722a7e029e5fb68c99f836aa1ab27c00.jpg' },
  { id: 3, name: 'Product 3', imageUrl: 'https://i.pinimg.com/236x/d2/b6/1a/d2b61aa69adf451508341c3642285557.jpg' },
  { id: 4, name: 'Product 4', imageUrl: 'https://i.pinimg.com/236x/95/29/8f/95298f17b85e478d278dcb7d8b08d110.jpg' }
];

const App61 = () => {
  return (
    <Provider store={store}>
      <View>
        <ProductList products={products} />
        <Cart />
      </View>
    </Provider>
  );
};

export default App61;

const styles = StyleSheet.create({});